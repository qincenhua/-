from capture.recognizable_capture import RecognizableCapture

capture = RecognizableCapture()
